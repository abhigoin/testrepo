class test_class:

    @staticmethod
    def read_data():
        """
        This method reads data from snowflake
        :param: spark
        :return: dataframe
        """
        print("abhishek ahs made the package")

    